//
//  ViewController.swift
//  demo614checkbox
//
//  Created by Yogesh Patel on 26/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController, BEMCheckBoxDelegate {
    @IBOutlet var checkbox1: BEMCheckBox!
    
    @IBOutlet var checkbox2: BEMCheckBox!
    override func viewDidLoad() {
        super.viewDidLoad()
        checkbox1.delegate = self
        checkbox2.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    func didTap(_ checkBox: BEMCheckBox) {
        if checkBox.tag == 1{
            self.view.backgroundColor = UIColor.black
        } else if checkBox.tag == 2{
            self.view.backgroundColor = UIColor.brown
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

